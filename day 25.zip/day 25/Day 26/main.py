import tkinter
from builtins import input
from tkinter import *

window = tkinter.Tk()

window.title("Hemu 1st GUI Program")
window.minsize(width=500, height=300)

# label

my_label = tkinter.Label(text="I Am Label", font=("Ariel", 24, "bold"))
my_label.pack(side="left")
# my_label

my_label.config(text="new text")


def click_button():
    print("I got clicked")
    # input = Entry()
    # input.pack()
    my_label.config(text=input.get())
    my_label.pack()

input = Entry()

input.pack()

button = Button(text="Click Me", command=click_button)
button.pack()




window.mainloop()
