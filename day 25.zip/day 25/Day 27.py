def add(*args):
    sum_of_data = 0
    for n in args:
        print(n)
        sum_of_data += n
    print(sum_of_data)


add(3, 5, 4, 2)


class bike:

    def __init__(self, **kw):
        self.make = kw["make"]
        self.model = kw["model"]
        self.price = kw.get("price")


my_bike = bike(make="unicorn", model="bs6")

print(my_bike.make)
print(my_bike.price)
