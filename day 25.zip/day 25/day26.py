# numbers = [1, 3, 6]
#
# new_item = [n + 1 for n in numbers]
#
# print(new_item)


# name = 'Hemchand'
#
# new_name = [n for n in name]
#
# print(new_name)

# range_list = [n * 2 for n in range(1, 5)]
#
# print(range_list)
#
#
# names = ['Hemu', 'Raj', 'Sanjay', 'Hemchand']
#
# # name_list = [name for name in names if len(name) < 7]
# #
# # print(name_list)
#
# upper_name = [name.upper() for name in names if len(name) < 7]
# print(upper_name)


# numbers = [1, 3, 5, 7, 9, 21, 15]
#
# square_number = [n * n for n in numbers]
# print(square_number)

numbers = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]

result = [num for num in numbers if num % 2 == 0]

print(result)
#
# chess_num = 2
# chess_game = [i for i in range(2, 65)]
#
# print(chess_num)
# print(chess_game)
