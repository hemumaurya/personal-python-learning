weather_r = {
    "Monday": 12,
    "Tuesday": 14,
    "Wednesday": 15,
    "Thursday": 14,
    "Friday": 21,
    "Saturday": 22,
    "Sunday": 24
}

temp_in_ferenheight = {keys: (values * 9/5) + 32 for (keys, values) in weather_r.items()}

print(temp_in_ferenheight)


