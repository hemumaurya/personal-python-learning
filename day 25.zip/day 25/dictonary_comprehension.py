# import random
#
# names = ['Dhanesh', 'Ajay', 'Aman', 'Abhishek', 'Hemchand', 'Sanjay', 'Rajan', 'Sujit']
#
# list_dict = {student: random.randint(0, 100) for student in names}
#
# passed_student = {student: score for (student, score) in list_dict.items() if score >= 60}
#
# print(list_dict)
# print(passed_student)

sentance_txt = "What is the Airspeed Velocity of an unladen Swallow?"

sentance_txt = sentance_txt.split(" ")

print(sentance_txt)

word_dict = {word: len(word) for word in sentance_txt}

print(word_dict)


