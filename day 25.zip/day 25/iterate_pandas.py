# student_dict = {
#     "student": ["Sanjay", "Rajan", "Hemchand"],
#     "score": [90, 80, 70]
# }
#
# # for (keys, values) in student_dict.items():
# #     print(values)
#
# import pandas
#
# student_data_frame = pandas.DataFrame(student_dict)
#
# # print(student_data_frame)
#
# for (index, row) in student_data_frame.iterrows():
#     # print(index)
#     # print(row)
#     if row.student == 'Hemchand':
#         print(row.score)
import pandas

data = pandas.read_csv('nato_phonetic_alphabet.csv')
# print(data.to_dict())

phanetic_dict = {rows.letter: rows.code for (index, rows) in data.iterrows()}

print(phanetic_dict)

word = input("Enter a word").upper()

output_dict = [phanetic_dict[letter] for letter in word.replace(' ', '')]
print(output_dict)

# with open('nato_phonetic_alphabet.csv', 'r') as data:
#     nato_data = pandas.DataFrame(data)
#
# print(nato_data.letter)


