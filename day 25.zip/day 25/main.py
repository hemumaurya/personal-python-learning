# # # with open('weather_data.csv') as file:
# # #
# # #     file_lists = file.readlines()
# # #     print(file_lists)
# # # for row in file_lists:
# # #     print(row.strip())
# # #
# # # import csv
# # #
# # # with open('weather_data.csv') as data_list:
# # #     data = csv.reader(data_list)
# # #     print(data)
# # #     tempratures = []
# # #     for row in data:
# # #         if row[1] != 'temp':
# # #             tempratures.append(int(row[1]))
# # #     print(tempratures)
# #
# # # print(row[1])
# #
# # import pandas as pd
# #
# # data = pd.read_csv('weather_data.csv')
# # # print(type(data))
# # #
# # # print(data["temp"])
# #
# # # dict_data = data.to_dict()
# # #
# # # print(dict_data['day'])
# # #
# # # print(len(dict_data['day']))
# # #
# # temp_list = data['temp'].to_list()
# #
# # print(temp_list)
# # # print(temp_list[0])
# # # temp = 0
# # # for val in temp_list:
# # #     temp = temp + float(val)
# # #
# # # average_temp = sum(temp_list) / len(temp_list)
# # # print(average_temp)
# #
# # print(data['temp'].max())
# #
# # print(data[data['temp'] == data['temp'].max()])
# #
# #
# # monday = data[data.day == "Monday"]
# # print(monday.temp * 9/5 + 32)
# import pandas
#
# data_dict = {
#     "students": ["Hemu", "Sanjay", "Rajan"],
#     "scores": [75, 89, 48]
# }
#
# data = pandas.DataFrame(data_dict)
# print(data)
# data.to_csv("test_v1.csv")
#

import pandas as pd

gray_counter = 0
cinnamon_counter = 0
black_counter = 0
with open('2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv') as data_file:
    park_data = pd.read_csv(data_file)

    color_data = park_data['Primary Fur Color']
    gray_color_count = len(park_data[park_data['Primary Fur Color'] == "Gray"])
    black_color_count = len(park_data[park_data['Primary Fur Color'] == "Black"])
    cinnamon_color_count = len(park_data[park_data['Primary Fur Color'] == "Cinnamon"])

color_list = {
    "name": ["Gray", "Black", "Cinnamon"],
    "count": [gray_color_count, black_color_count, cinnamon_color_count]
}

color_data_save = pd.DataFrame(color_list)
print(color_data_save)
color_data_save.to_csv("color_data_v1.csv")





#
#     for row in color_data:
#         if row == "Gray":
#             gray_counter = gray_counter + 1
#         elif row == "Black":
#             black_counter = black_counter + 1
#         elif row == "Cinnamon":
#             cinnamon_counter = cinnamon_counter + 1
#         else:
#             print("Color Not Found")
# print(gray_counter, black_counter, cinnamon_counter)
# color_list = {
#     "name": ["Gray", "Black", "Cinnamon"],
#     "count": [gray_counter, black_counter, cinnamon_counter]
# }
#
# color_data_save = pd.DataFrame(color_list)
# print(color_data_save)
# color_data_save.to_csv("color_data.csv")



