#TODO: Create a letter using starting_letter.txt 
#for each name in invited_names.txt
#Replace the [name] placeholder with the actual name.
#Save the letters in the folder "ReadyToSend".
    
#Hint1: This method will help you: https://www.w3schools.com/python/ref_file_readlines.asp
    #Hint2: This method will also help you: https://www.w3schools.com/python/ref_string_replace.asp
        #Hint3: THis method will help you: https://www.w3schools.com/python/ref_string_strip.asp

with open('../Mail Merge Project Start/Input/Names/invited_names.txt') as name_file:
    names = name_file.readlines()
    # for name in names:
    #     print(name)
    # # print(name_file.readlines())

with open('../Mail Merge Project Start/Input/Letters/starting_letter.txt') as invited_file:
    template = invited_file.read()
    for name in names:
        name = name.strip()
        invite_template = template.replace('[name]', name)
        with open(f'../Mail Merge Project Start/Output/ReadyToSend/invite_to_{name}.txt', mode='w') as save_temp:
            save_temp.write(invite_template)



