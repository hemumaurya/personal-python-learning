import os

# Specify the directory path
directory_path = "../Mail Merge Project Start/Output/ReadyToSend"

# Create the directory if it doesn't exist
if not os.path.exists(directory_path):
    os.makedirs(directory_path)

# Create a new file inside the specified directory
file_path = os.path.join(directory_path, "myfile.txt")

try:
    with open(file_path, "w") as file:
        file.write("Hello, World!\n")
except IOError as e:
    print(f"An error occurred: {e}")
