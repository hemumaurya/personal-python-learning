# database
import psycopg2

cur = None
con = None


def connect_to_db(hostname, database, username, password, port_id):
    # db credentials
    hostname = hostname
    database = database
    username = username
    password = password
    port_id = port_id

    con = psycopg2.connect(host=hostname, dbname=database,
                           user=username, password=password, port=port_id)
    cur = con.cursor()

    return [cur, con]

    # delete_script="""Delete from public.employee_leaves_data"""
    # cur.execute(delete_script)
    # con.commit()


def insert_data(cursor, conn, data):
    for line in data:
        for li in line:
            print(type(li))
        print(line)
        insert_script = '''INSERT INTO poc.survey_master_data_backup(
	year, district, village, taluka, subdivision_id, subdivision_name, survey_numbers, open_land, residential_land, offices, shops, unit_cost, village_result_portal, status,industrial)
	VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);'''
        insert_value = (
            line[0], line[3], line[2], line[1], line[4], str(line[5]), line[6], line[7], line[8], line[9], line[10],
            line[11], line[12], line[13], line[14])
        # cur.executemany(insert_script, data)
        cursor.execute(insert_script, insert_value)

        conn.commit()

        update_query = "update poc.master_district_village set status ='Completed' where district='" + line[
            3] + "' and village_result_portal ='" + line[12] + "' and taluka ='" + line[1] + "'"
        cursor.execute(update_query)
        conn.commit()
    # update_query='''UPDATE poc.survey_number_master SET upvibhag_id  = split_part(upvibhag ,'-', 1)'''
    # cur.execute(update_query)
    # con.commit()   
    # # close connection
    # cursor.close()
    # conn.close()                    


# connect_to_db('karma-db.neebal.com','pmi_db','pmi_web_user','G@Rtav#2x52f',5432)

def select_data(cursor, district, taluka):
    select_query = "select * from poc.master_district_village mdv where district ='" + district + "' and taluka ='" + taluka + "' and status='Pending'"

    cursor.execute(select_query)
    ans = cursor.fetchall()
    return ans


def insert_data2(currrr, conn, line):
    print(line)
    insert_script = '''INSERT INTO poc.survey_master_data_backup(
            year, district, village, taluka, subdivision_id, subdivision_name, survey_numbers, open_land, residential_land, offices, shops, unit_cost, village_result_portal, status,industrial,assesment_type, assesment_range, rate, unit,vibhag_number)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s);'''
    insert_value = (
        str(line[0]), str(line[3]), str(line[2]), str(line[1]), str(line[4]), str(line[5]), str(line[6]), str(line[7]),
        str(line[8]), str(line[9]), str(line[10]), str(line[11]), str(line[12]), str(line[13]), str(line[14]),
        str(line[15]), str(line[16]), str(line[17]), str(line[18]), str(line[19]))
    # cur.executemany(insert_script, data)
    currrr.execute(insert_script, insert_value)

    conn.commit()

    update_query = "update poc.master_district_village set status ='Completed' where district='" + line[
        3] + "' and village_search_portal ='" + line[2] + "' and taluka ='" + line[1] + "'"
    currrr.execute(update_query)
    conn.commit()
