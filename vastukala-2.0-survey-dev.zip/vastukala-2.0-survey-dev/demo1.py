import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException,StaleElementReferenceException



PATH = "C:\Program Files (x86)\chromedriver.exe"
serv_obj = Service(PATH)
driver = webdriver.Chrome(service=serv_obj)

# Maximize the window
driver.maximize_window()


# open url
driver.get("https://igreval.maharashtra.gov.in/eASR2.0/eASRCommon.aspx?hDistName=Bombaymains")
# wait for 5sec after url is loaded
time.sleep(5)

# villages=["आनिक - कुर्ला","आसल्फे - कुर्ला"]
villages=["आनिक - कुर्ला","आसल्फे - कुर्ला","भांडुप - कुर्ला","बोरला - कुर्ला","चांदिवली - कुर्ला","चेंबूर - कुर्ला","देवनार - कुर्ला","घाटकोपर - किरोळ - कुर्ला","घाटकोपर - कुर्ला","हरियाली - कुर्ला","कलिना - कुर्ला","कांजूर - कुर्ला","किरोळ - कुर्ला","कोपरी - कुर्ला","कुर्ला - 1","कुर्ला - 2","कुर्ला - 3","कुर्ला - 4","माहुल - कुर्ला","मानबुद्रुक - कुर्ला","मंडाले - कुर्ला","मानखुर्द - कुर्ला","मारवली - कुर्ला","मोहिली - कुर्ला","मुलुंड ( प ) - कुर्ला","मुलुंड ( पू ) - कुर्ला","नाहुर - कुर्ला","नानोले - कुर्ला","पासपोली - कुर्ला","पवई - कुर्ला","साकी - कुर्ला","तिरंदाज - कुर्ला","तुंगवा - कुर्ला","तुर्भे - कुर्ला","वडवली - कुर्ला","विक्रोळी - कुर्ला","आंबिवली ( अंधेरी )","अंधेरी ( अंधेरी )","बांदीवली ( अंधेरी )","बांद्रा - ए ( अंधेरी )","बांद्रा - बी ( अंधेरी )","बांद्रा - सी ( अंधेरी )","बांद्रा - डी ( अंधेरी )","बांद्रा - ई ( अंधेरी )","बांद्रा - पुर्व  ( अंधेरी )","बांद्रा - एफ ( अंधेरी )","बांद्रा - जी ( अंधेरी )","बांद्रा - एच ( अंधेरी )","बांद्रा - आय ( अंधेरी )","बापनाळा ( अंधेरी )","ब्राम्हणवाडा ( अंधेरी )","चकाला ( अंधेरी )","गुंदवली ( अंधेरी )","इस्मालिया ( अंधेरी )","जुहू ( अंधेरी )","कोळेकल्याण ( अंधेरी )","कोंदीविटे ( अंधेरी )","मढ ( अंधेरी )","मजास ( अंधेरी )","मरोळ ( अंधेरी )","मोगरा ( अंधेरी )","मुळगांव ( अंधेरी )","ओशिवरे ( अंधेरी )","परीघाखाडी ( अंधेरी )","परजापूर ( अंधेरी )","सहार ( अंधेरी )","वर्सोवा ( अंधेरी )","विलेपार्ले पश्चिम ( अंधेरी )","विलेपार्ले पुर्व ( अंधेरी )","व्यारवली ( अंधेरी )","आरे ( बोरीवली )","आक्से ( बोरीवली )","आकुर्ली ( बोरीवली )","बोरीवली ( बोरीवली )","चारकोप ( बोरीवली )","चिंचवली ( बोरीवली )","क्लेराबाद ( बोरीवली )","दहीसर ( बोरीवली )","दारवली ( बोरीवली )","दिंडोशी ( बोरीवली )","एकसर ( बोरीवली )","पहाडी-एकसर ( बोरीवली )","एरंगळ ( बोरीवली )","गोराई ( बोरीवली )","गोरेगाव ( बोरीवली )","गुंदगाव ( बोरीवली )","कांदीवली बोरीवली","कणेरी ( बोरीवली )","कुरार ( बोरीवली )","मागाठाणे ( बोरीवली )","मालाड ( पुर्व ) ( बोरीवली )","मालाड ( उत्तर ) ( बोरीवली )","मालाड ( दक्षिण ) ( बोरीवली )","मालवणी ( बोरीवली )","मालवणी- बोरिवली","मंडपेश्वर (बोरीवली)","मनोरी ( बोरीवली )","मरोशी-बोरिवली","मारवे ( बोरीवली )","पहाडी-गोरेगाव पुर्व ( बोरीवली )","पहाडी-गोरेगाव पश्चिम ( बोरीवली )","पोईसर ( बोरीवली )","साई ( बोरीवली )","शिंपवली ( बोरीवली )","तुळशी ( बोरीवली )","वाढवण ( बोरीवली )","वळणई ( बोरीवली )"]
years=['2023-2024']

main_body=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[1]/td/table/tbody/tr[3]')


arr=[]
temp_arr=[]
for village in villages:
    # select Year
    for year in years:
        try:
            select_year=driver.find_element(By.XPATH,"/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[1]/td[2]/select")
            s_year=Select(select_year)
            s_year.select_by_visible_text(year)
        except NoSuchElementException:
            select_year=driver.find_element(By.XPATH,"/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[1]/td[2]/select")
            s_year=Select(select_year)
            s_year.select_by_visible_text(year)
            
        try:
            time.sleep(5)
            # select village
            select_village=driver.find_element(By.XPATH,"/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[2]/td/div/table/tbody/tr[5]/td[2]/select")
            s_village=Select(select_village)
            s_village.select_by_visible_text(village)
        except StaleElementReferenceException:
            time.sleep(5)
            # select village
            select_village=driver.find_element(By.XPATH,"/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[2]/td/div/table/tbody/tr[5]/td[2]/select")
            s_village=Select(select_village)
            s_village.select_by_visible_text(village)
            
            
            
            
        try:
        # wait for data table to appear
            main_data_table=WebDriverWait(driver, 25).until(EC.presence_of_element_located((By.XPATH, "/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table")))
            if main_data_table.is_displayed():
                continue
            else:
                time.sleep(10)
                main_data_table=WebDriverWait(driver, 25).until(EC.presence_of_element_located((By.XPATH, "/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table")))
                
        except NoSuchElementException:
            time.sleep(10)
            main_data_table=WebDriverWait(driver, 25).until(EC.presence_of_element_located((By.XPATH, "/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table")))
            
        if main_data_table.is_displayed():
            print("!!!! MAIN DATA TABLE VISIBLE !!!!")
            print(village)
  
            
            page_count=2
            while True:
                try:
                    row_count=2 

                    while True:
                        try:
                            print('row_count',row_count)

                            # click on each row to get survey numbers
                            print(driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[1]/a').text)
                            # survey_element=WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[1]/a'))).click()
                            # driver.execute_script("arguments[0].click();", survey_element)
                            time.sleep(2)

                            # subdivision
                            subdivision=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[2]').text
                            # print(subdivision)	
                            # open land    
                            open_land=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[3]').text
                            # Residential Flats	
                            residential_flats=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[4]').text
                            # Office	
                            office=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[5]').text
                            # shops	
                            shops=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[6]').text
                            # # Industrial
                            industrial=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[7]').text
                            # Unit (Rs./)
                            unit_charges=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[8]').text
                            temp_arr=[year,village,subdivision,open_land,residential_flats,office,shops,industrial,unit_charges]

                            arr.append(temp_arr)
                            temp_arr=[]

                            time.sleep(2.5)
                            row_count+=1
                        except NoSuchElementException:
                            break;
                    # click on next page
                    driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[7]/td/table/tbody/tr/td['+str(page_count)+']').click()
                    page_count+=1
                    time.sleep(15)
                except NoSuchElementException:
                    break
        # driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[7]/td/table/tbody/tr/td['+str(page_count)+']/a').click()
        # time.sleep(10)
        # print('page_count',page_count)
        # page_count+=1

            
        # to refresh the page
        driver.refresh()
        time.sleep(5)


print(arr)

driver.close()
    