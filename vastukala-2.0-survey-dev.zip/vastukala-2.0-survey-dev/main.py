import time
from db_connect import connect_to_db, insert_data, select_data
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException,StaleElementReferenceException
from dotenv import load_dotenv
import os
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options


load_dotenv()
db_var=connect_to_db(os.getenv('DB_HOST'),os.getenv('DB_NAME'),os.getenv('DB_USER'),os.getenv('DB_PASS'),5432)

# taluka_arr=['मुंबई']
taluka_arr=['शहापूर','कल्याण','उल्हासनगर','मुरबाड','भिवंडी','ठाणे']

for t in taluka_arr:
    visual_district='Thane'
    op=select_data(db_var[0],'ठाणे',t)
    op_arr=[]
    op_temp_arr=[]
    for o in op:
        # print(o)
        for i in o:
            op_temp_arr.append(i)
        op_arr.append(op_temp_arr)
        op_temp_arr=[]
        

    for p in op_arr:
        print('village_search_portal',p[3])
        print('district',p[1])
        print('taluka',p[2])
        print('village_portal_result',p[4])




    chrome_options = Options()
    driver_path = ChromeDriverManager().install()

    service = Service(driver_path)

        # Create a WebDriver instance with the Service and ChromeOptions
    driver = webdriver.Chrome(service=service, options=chrome_options)

    # Maximize the window
    driver.maximize_window()






    # open url
    # driver.get("https://igreval.maharashtra.gov.in/eASR2.0/eASRCommon.aspx?hDistName=Bombaymains")
    driver.get("https://igreval.maharashtra.gov.in/eASR2.0/eASRCommon.aspx?hDistName=Thane")
    # wait for 5sec after url is loaded
    time.sleep(5)

    # villages=["आनिक - कुर्ला","आसल्फे - कुर्ला"]
    years=['2023-2024']



    for year in years:
        
        for p in op_arr:
            arr=[]
            temp_arr=[]
            district_change=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[2]/td/div/table/tbody/tr[1]/td[2]/select')
            s_district=Select(district_change)
            s_district.select_by_visible_text(visual_district)
            time.sleep(15)
            village=p[3]
            taluka=p[2]
            district=p[1]
            village_portal_result=p[4]
            print("selected village - ",village,'\n','selected Year - ',year)
            time.sleep(10)
            main_page=driver.find_element(By.XPATH,'/html/body/form/div[3]')
            try:
                if main_page:
                    print("exists")
                    # select year            
                    select_year=driver.find_element(By.XPATH,"/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[1]/td[2]/select")
                    s_year=Select(select_year)
                    s_year.select_by_visible_text(year)
                    
                    
                    select_taluka=driver.find_element(By.XPATH,"/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[2]/td/div/table/tbody/tr[3]/td[2]/select")
                    if select_taluka.is_displayed():
                        print("Taluka available")
                        s_taluka=Select(select_taluka)
                        s_taluka.select_by_visible_text(t)
                        time.sleep(10)
                        
                    
                    # select villgae
                    select_village=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[2]/td/div/table/tbody/tr[5]/td[2]/select')
                    s_village=Select(select_village)
                    s_village.select_by_visible_text(village)
                    time.sleep(5)
                    
                    # wait for listing table to appear
                    time.sleep(5)
                    listing_table=WebDriverWait(driver, 100).until(EC.presence_of_element_located((By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table')))
                    if listing_table:
                        print('MAIN LISTING TABLE VISIBLE')
                        time.sleep(20)
                        page_count=2
                        while True :
                            try:
                                
                                row_count=2
                                # rows action
                                while True:
                                    try:
                                        rows=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[1]/a')
                                        rows.click()
                                        time.sleep(1)
                                        survey_numbers=WebDriverWait(driver, 100).until(EC.presence_of_element_located((By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[2]/td[2]/textarea'))).text
                                        
                                        # subdivision
                                        subdivision=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[2]').text
                                        time.sleep(1)
                                        subdivision=subdivision.split('-',1)
                                        if len(subdivision)>1:
                                            subdivision_id=subdivision[0]
                                            subdivision_name=subdivision[1]
                                        else:
                                            subdivision_id=subdivision[0]
                                            
                                        # open land    
                                        open_land=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[3]').text
                                        time.sleep(1)
                                        # Residential Flats	
                                        residential_flats=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[4]').text
                                        time.sleep(1)
                                        # Office	
                                        office=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[5]').text
                                        time.sleep(1)
                                        # shops	
                                        shops=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[6]').text
                                        # Industrial
                                        time.sleep(1)
                                        industrial=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[7]').text
                                        # Unit (Rs./)
                                        time.sleep(1)
                                        unit_charges=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr['+str(row_count)+']/td[8]').text
                                        # print(year,village,subdivision,survey_numbers,open_land,residential_flats,office,shops,industrial,unit_charges)
                                        # temp_arr=[year,village,subdivision_id,survey_numbers,open_land,residential_flats,office,shops,industrial,unit_charges]
                                        temp_arr=[year,  taluka, village,district, subdivision_id, subdivision_name, survey_numbers, open_land, residential_flats, office, shops, unit_charges, village_portal_result, 'pending',industrial]
                                        arr.append(temp_arr)
                                        temp_arr=[]
                                        time.sleep(1)
                                        row_count+=1
                                    except NoSuchElementException:
                                        break
                                # click on next page
                                next_page=driver.find_element(By.XPATH,'/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[7]/td/table/tbody/tr/td['+str(page_count)+']').click()
                                time.sleep(40)
                                page_count+=1
                                time.sleep(5)
                            except NoSuchElementException:
                                print(page_count)
                                print("No more pages available")
                                break
                        time.sleep(10)
                    else:
                        print("LISTING TABLE NOT VISIBLE")
                        time.sleep(10)
                else:
                    print('Not exists')        
                driver.refresh()
                time.sleep(5)
                insert_data(db_var[0],db_var[1],arr)
                print("Page Refreshed")
            except NoSuchElementException:
                continue
    for a in arr :
        print(a)