import time
from db_connect import connect_to_db, insert_data2, select_data
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from dotenv import load_dotenv
import os
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

load_dotenv()
db_var = connect_to_db(os.getenv('DB_HOST'), os.getenv('DB_NAME'), os.getenv('DB_USER'), os.getenv('DB_PASS'), 5432)

# taluka_arr=['मुंबई']
# taluka_arr=['शहापूर','कल्याण','उल्हासनगर','मुरबाड','भिवंडी','ठाणे']
# taluka_arr=['Murbad','Shahpur','Ulhasnagar','Thane','Kalyan',]
# taluka_arr=['Thane']
taluka_arr = ['Murud', 'Poladpur', 'Mangaon', 'Sudhagarh', 'Srivardhan', 'Alibagh', 'Roha', 'Khalapur', 'Mahad',
              'Mhasala', 'Tala']
for taluka_list in taluka_arr:
    visual_district = 'Raigad'
    village_list_for_taluka = select_data(db_var[0], 'रायगड', taluka_list)
    print("Printing op : - ", village_list_for_taluka)
    print("Current taluka list is ", taluka_list)
    data_array_list = []
    op_temp_arr = []
    for single_record_of_village in village_list_for_taluka:
        print("Printing single record of village list ", single_record_of_village)
        # print(o)
        for i in single_record_of_village:
            print("Printing value of i ", i)
            print("Appending op temp array")
            op_temp_arr.append(i)
        print("Appending op array value")
        data_array_list.append(op_temp_arr)
        print("making empty array op temp array value")
        op_temp_arr = []

    print("Printing op array value")
    print(data_array_list)
    print("After printing op array value")

    # print("Before entering op array")
    # for value_from_data_array_list in data_array_list:
    #     print('village_search_portal', value_from_data_array_list[3])
    #     print('district', value_from_data_array_list[1])
    #     print('taluka', value_from_data_array_list[2])
    #     print('village_portal_result', value_from_data_array_list[4])
    #     print("----------------------------")
    #     print("One record completed")

    # time.sleep(100)
    chrome_options = Options()
    driver_path = ChromeDriverManager().install()

    service = Service(driver_path)

    # Create a WebDriver instance with the Service and ChromeOptions
    driver = webdriver.Chrome(service=service, options=chrome_options)

    # Maximize the window
    driver.maximize_window()

    # open url
    print("Opening portal for that district")
    driver.get("https://igreval.maharashtra.gov.in/eASR2.0/eASRCommon.aspx?hDistName=Raigad")
    # driver.get("https://easr.igrmaharashtra.gov.in/eASRCommon.aspx?hDistName=Thane")
    # wait for 5sec after url is loaded
    time.sleep(5)

    # villages=["आनिक - कुर्ला","आसल्फे - कुर्ला"]
    print("Here is year for data extraction")
    years = ['2023-2024']

    print("Entering year loop")
    for year in years:

        for value_from_data_array_list in data_array_list:
            print(value_from_data_array_list)
            # select language
            time.sleep(10)
            try:
                languagae_change = WebDriverWait(driver, 2000).until(EC.presence_of_element_located(
                    (By.XPATH, '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[1]/td[4]/select')))

                if languagae_change.is_displayed():
                    s_language = Select(languagae_change)
                    s_language.select_by_visible_text('Marathi')
            except NoSuchElementException:
                continue
            time.sleep(4)
            arr = []
            temp_arr = []
            district_change = driver.find_element(By.XPATH,
                                                  '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[2]/td/div/table/tbody/tr[1]/td[2]/select')
            s_district = Select(district_change)
            s_district.select_by_visible_text(visual_district)
            time.sleep(15)
            village = value_from_data_array_list[3]
            taluka = value_from_data_array_list[2]
            district = value_from_data_array_list[1]
            village_portal_result = value_from_data_array_list[4]
            print("selected village - ", village, '\n', 'selected Year - ', year)
            time.sleep(10)
            main_page = driver.find_element(By.XPATH, '/html/body/form/div[3]')
            try:
                if main_page:
                    print("exists")
                    # select year
                    print("Before selecting year")
                    select_year = driver.find_element(By.XPATH,
                                                      "/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[1]/td[2]/select")
                    s_year = Select(select_year)
                    s_year.select_by_visible_text(year)

                    print("Before selecting taluka")
                    select_taluka = driver.find_element(By.XPATH,
                                                        "/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[2]/td/div/table/tbody/tr[3]/td[2]/select")
                    if select_taluka.is_displayed():
                        print("Taluka available")
                        s_taluka = Select(select_taluka)
                        s_taluka.select_by_visible_text(t)
                        time.sleep(10)

                    # select villgae
                    print("Before selecting village")
                    select_village = driver.find_element(By.XPATH,
                                                         '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[1]/tr[2]/td/div/table/tbody/tr[5]/td[2]/select')
                    s_village = Select(select_village)
                    s_village.select_by_visible_text(village)
                    time.sleep(5)

                    # wait for listing table to appear
                    time.sleep(15)
                    print("Before selecting table and reading")
                    listing_table = WebDriverWait(driver, 100).until(EC.presence_of_element_located(
                        (By.XPATH, '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table')))
                    if listing_table:
                        print('MAIN LISTING TABLE VISIBLE')
                        time.sleep(20)

                        # Find all header (th) or data cell (td) elements within the first row of the table
                        first_row_cells = listing_table.find_elements(By.XPATH, './/tr[1]/th|td')

                        # Count the number of columns
                        num_columns = len(first_row_cells)
                        print('num_columns', num_columns)

                        if num_columns == 4:
                            print("First")
                            vibhag_number = ''
                            Assesment_Type = ''
                            Assesment_Range = ''
                            Rate = ''
                            Unit = ''
                            subdivision_id = ''
                            subdivision_name = ''
                            survey_numbers = ''
                            open_land = ''
                            residential_flats = ''
                            office = ''
                            shops = ''
                            unit_charges = ''
                            village_portal_result = ''
                            industrial = ''
                            page_count = 2
                            while True:
                                try:

                                    row_count = 2
                                    # rows action
                                    while True:
                                        try:

                                            # subdivision
                                            Assesment_Type = driver.find_element(By.XPATH,
                                                                                 '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[2]/td/div/table/tbody/tr[' + str(
                                                                                     row_count) + ']/td[1]').text
                                            time.sleep(1)

                                            # open land    
                                            Assesment_Range = driver.find_element(By.XPATH,
                                                                                  '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[2]/td/div/table/tbody/tr[' + str(
                                                                                      row_count) + ']/td[2]').text
                                            time.sleep(1)
                                            # Residential Flats	
                                            Rate = driver.find_element(By.XPATH,
                                                                       '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[2]/td/div/table/tbody/tr[' + str(
                                                                           row_count) + ']/td[3]').text
                                            time.sleep(1)
                                            # shops	
                                            Unit = driver.find_element(By.XPATH,
                                                                       '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[2]/td/div/table/tbody/tr[' + str(
                                                                           row_count) + ']/td[4]').text
                                            # Industrial
                                            time.sleep(1)

                                            vibhag_number = driver.find_element(By.XPATH,
                                                                                '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td[2]/span').text
                                            time.sleep(1)

                                            # print(year,village,subdivision,survey_numbers,open_land,residential_flats,office,shops,industrial,unit_charges)
                                            # temp_arr=[year,village,subdivision_id,survey_numbers,open_land,residential_flats,office,shops,industrial,unit_charges]
                                            temp_arr = [year, taluka, village, district, subdivision_id,
                                                        subdivision_name, survey_numbers, open_land, residential_flats,
                                                        office, shops, unit_charges, village_portal_result, 'pending',
                                                        industrial, Assesment_Type, Assesment_Range, Rate, Unit,
                                                        vibhag_number]
                                            arr.append(temp_arr)
                                            insert_data2(db_var[0], db_var[1], temp_arr)
                                            temp_arr = []
                                            time.sleep(1)
                                            row_count += 1
                                        except NoSuchElementException:
                                            break
                                    # click on next page
                                    next_page = driver.find_element(By.XPATH,
                                                                    '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[7]/td/table/tbody/tr/td[' + str(
                                                                        page_count) + ']').click()
                                    time.sleep(40)
                                    page_count += 1
                                    time.sleep(5)
                                except NoSuchElementException:
                                    print('page_count', page_count)
                                    print("No more pages available")
                                    break
                            time.sleep(10)




                        else:
                            # click on  survey number radio button
                            survey_radio_btn = driver.find_element(By.XPATH,
                                                                   "/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[1]/td/div/table/tbody/tr[1]/td[3]/span/input").click()
                            time.sleep(5)
                            print("Second ")
                            Assesment_Type = ''
                            Assesment_Range = ''
                            Rate = ''
                            Unit = ''
                            page_count = 2
                            vibhag_number = ''
                            while True:
                                try:

                                    row_count = 2
                                    # rows action
                                    while True:
                                        try:

                                            rows = driver.find_element(By.XPATH,
                                                                       '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[' + str(
                                                                           row_count) + ']/td[1]/a')
                                            rows.click()
                                            time.sleep(1)
                                            survey_numbers = WebDriverWait(driver, 100).until(
                                                EC.presence_of_element_located((By.XPATH,
                                                                                '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[2]/td[2]/textarea'))).text

                                            # subdivision
                                            subdivision = driver.find_element(By.XPATH,
                                                                              '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[' + str(
                                                                                  row_count) + ']/td[2]').text
                                            time.sleep(1)
                                            subdivision = subdivision.split('-', 1)
                                            if len(subdivision) > 1:
                                                subdivision_id = subdivision[0]
                                                subdivision_name = subdivision[1]
                                            else:
                                                subdivision_id = subdivision[0]

                                            # open land    
                                            open_land = driver.find_element(By.XPATH,
                                                                            '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[' + str(
                                                                                row_count) + ']/td[3]').text
                                            time.sleep(1)
                                            # Residential Flats	
                                            residential_flats = driver.find_element(By.XPATH,
                                                                                    '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[' + str(
                                                                                        row_count) + ']/td[4]').text
                                            time.sleep(1)
                                            # Office	
                                            office = driver.find_element(By.XPATH,
                                                                         '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[' + str(
                                                                             row_count) + ']/td[5]').text
                                            time.sleep(1)
                                            # shops	
                                            shops = driver.find_element(By.XPATH,
                                                                        '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[' + str(
                                                                            row_count) + ']/td[6]').text
                                            # Industrial
                                            time.sleep(1)
                                            industrial = driver.find_element(By.XPATH,
                                                                             '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[' + str(
                                                                                 row_count) + ']/td[7]').text
                                            # Unit (Rs./)
                                            time.sleep(1)
                                            unit_charges = driver.find_element(By.XPATH,
                                                                               '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[' + str(
                                                                                   row_count) + ']/td[8]').text
                                            # print(year,village,subdivision,survey_numbers,open_land,residential_flats,office,shops,industrial,unit_charges)
                                            # temp_arr=[year,village,subdivision_id,survey_numbers,open_land,residential_flats,office,shops,industrial,unit_charges]
                                            temp_arr = [year, taluka, village, district, subdivision_id,
                                                        subdivision_name, survey_numbers, open_land, residential_flats,
                                                        office, shops, unit_charges, village_portal_result, 'pending',
                                                        industrial, Assesment_Type, Assesment_Range, Rate, Unit,
                                                        vibhag_number]
                                            arr.append(temp_arr)
                                            insert_data2(db_var[0], db_var[1], temp_arr)
                                            temp_arr = []
                                            time.sleep(1)
                                            row_count += 1
                                        except NoSuchElementException:
                                            break
                                    # click on next page
                                    next_page = driver.find_element(By.XPATH,
                                                                    '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[2]/td/table/tbody/tr[1]/td/div/table/tbody/tr[7]/td/table/tbody/tr/td[' + str(
                                                                        page_count) + ']').click()
                                    time.sleep(40)
                                    page_count += 1
                                    time.sleep(5)
                                except NoSuchElementException:
                                    print('page_count', page_count)
                                    print("No more pages available")
                                    break
                            time.sleep(10)

                    elif driver.find_element(By.XPATH,
                                             '/html/body/form/div[3]/table/tbody/tr[2]/td/div[1]/table/tbody[2]/tr[5]/td/span[contains(text(),"माहिती उपलब्ध नाही, विभागाला संपर्क करा.")]').is_displayed():
                        continue


                    else:
                        print("LISTING TABLE NOT VISIBLE")
                        time.sleep(10)
                else:
                    print('Not exists')

                driver.refresh()
                time.sleep(5)
                # insert_data2(db_var[0],db_var[1],arr)
                print("Page Refreshed")
            except NoSuchElementException:
                continue
    # for a in arr :
    #     print(a)
